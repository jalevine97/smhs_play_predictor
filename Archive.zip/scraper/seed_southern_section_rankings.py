import os
import time
from datetime import datetime
from dotenv import load_dotenv
from bs4 import BeautifulSoup
from supabase import create_client, Client
from playwright.sync_api import sync_playwright

# === Load Supabase ===
load_dotenv()
SUPABASE_URL = os.getenv("SUPABASE_URL")
SUPABASE_KEY = os.getenv("SUPABASE_KEY")
supabase: Client = create_client(SUPABASE_URL, SUPABASE_KEY)

BASE_URL = "https://www.maxpreps.com"
SECTION = "southern-section"

def fetch_ranking_page(page_num: int):
    url = f"{BASE_URL}/ca/{SECTION}/football/rankings/{page_num}/"
    with sync_playwright() as p:
        browser = p.chromium.launch(headless=True)
        page = browser.new_page()
        page.goto(url, timeout=60000)
        page.wait_for_timeout(6000)
        html = page.content()
        browser.close()
        return html

def extract_rankings(html):
    soup = BeautifulSoup(html, "html.parser")
    rankings = []

    rows = soup.select("table tbody tr")
    for row in rows:
        cols = row.find_all("td")
        if len(cols) < 5:
            continue
        try:
            rank = int(cols[0].text.strip())
            team_name = cols[1].text.strip()
            record = cols[2].text.strip()
            rating = float(cols[3].text.strip())
            strength = float(cols[4].text.strip())

            rankings.append({
                "team_name": team_name,
                "rank": rank,
                "record": record,
                "rating": rating,
                "strength": strength,
                "section": SECTION
            })
        except Exception as e:
            print("⚠️ Parse error:", e)
    return rankings

def get_latest_entry(team_name):
    res = supabase.table("team_rankings") \
        .select("rank, rating, strength, record, scrape_week") \
        .eq("team_name", team_name) \
        .order("scrape_week", desc=True) \
        .limit(1) \
        .execute()
    return res.data[0] if res.data else None

def should_insert(current, previous):
    if not previous:
        return True
    keys = ["rank", "rating", "strength", "record"]
    return any(current[k] != previous[k] for k in keys)

def insert_ranking(team):
    res = supabase.table("team_rankings").insert(team).execute()
    print(f"✅ Inserted {team['team_name']} (Week {team['scrape_week']})")

def main():
    today = datetime.utcnow()
    if not (8 <= today.month <= 12):
        print("⏳ Outside August–December range. Skipping scrape.")
        return
    if today.month == 12 and today.day > 15:
        print("✅ Past December 15 cutoff. Skipping scrape.")
        return

    scrape_week = today.isocalendar().week
    scrape_year = today.year

    total_inserted = 0
    for page_num in range(1, 20):
        html = fetch_ranking_page(page_num)
        teams = extract_rankings(html)

        if not teams:
            print(f"✅ Page {page_num} empty. Done.")
            break

        for team in teams:
            team["scrape_week"] = scrape_week
            team["scrape_year"] = scrape_year
            team["scraped_at"] = datetime.utcnow().isoformat()

            latest = get_latest_entry(team["team_name"])
            if should_insert(team, latest):
                insert_ranking(team)
                total_inserted += 1
            else:
                print(f"⏩ No change: {team['team_name']}")

            time.sleep(0.5)

    print(f"📦 Finished. {total_inserted} new entries.")

if __name__ == "__main__":
    main()
